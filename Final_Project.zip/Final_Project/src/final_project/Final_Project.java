/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package final_project;
import javax.swing.ImageIcon;
/**
 *
 * @author Hamza
 */
public class Final_Project {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
          SplashForm splash=new SplashForm();
        splash.setVisible(true);
       int i;         
        try {
            
            for (i =0; i<=99; i++){
                Thread.sleep(40);
            splash.plabel.setText(Integer.toString(i)+"%");
            splash.pbar.setValue(i);
            }
          if (i==100)  {
              splash.setVisible(false);
             new Screen_2().show(); }
          }
        
        
    catch(Exception e){
        System.out.println(e);
    }
      }
   
    }
    

